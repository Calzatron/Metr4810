/*
 * USART0_.h
 *
 * Created: 17/04/2017 6:50:36 PM
 *  Author: s4357594
 */ 


#ifndef USART0__H_
#define USART0__H_

//char input(void);

void USART0_init(long ubrr);

void output_char(char serialOut);

//void clear_serial_input_buffer(void);

//void output_string(char serialOutString[]);
//
//char input(void);
//
//void clear_output(void);


#endif /* USART0__H_ */