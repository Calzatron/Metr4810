/*
 * tcnt0.h
 *
 * Created: 3/05/2017 11:29:49 PM
 *  Author: Owner
 */ 


#ifndef TCNT0_H_
#define TCNT0_H_

void init_tcnt0(void);
uint32_t get_tcnt0_ticks(void);

#endif /* TCNT0_H_ */