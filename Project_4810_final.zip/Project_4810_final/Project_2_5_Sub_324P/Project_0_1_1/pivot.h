/*
 * pivot.h
 *
 * Created: 27/05/2017 3:45:58 PM
 *  Author: Callum
 */ 

#ifndef PIVOT_H_
#define PIVOT_H_

void pivot_off(void);
void move_pivot(int8_t direction);


#endif /* PIVOT_H_ */