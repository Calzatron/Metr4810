/*
 * worm.h
 *
 * Created: 22/05/2017 5:20:39 AM
 *  Author: Owner
 */ 


#ifndef WORM_H_
#define WORM_H_

void move_worm(uint8_t percent, int8_t direction);
void worm_off(void);

#endif /* WORM_H_ */