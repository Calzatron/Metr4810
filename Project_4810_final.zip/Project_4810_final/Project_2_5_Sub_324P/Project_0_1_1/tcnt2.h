/*
 * tcnt2.h
 *
 * Created: 17/04/2017 6:45:56 PM
 *  Author: s4357594
 */ 


#ifndef TCNT2_H_
#define TCNT2_H_

#include <stdint.h>
void init_tcnt2(void);

#endif /* TCNT2_H_ */