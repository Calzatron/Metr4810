/*
 * servo.h
 *
 * Created: 26/05/2017 1:21:49 AM
 *  Author: Owner
 */ 


#ifndef SERVO_H_
#define SERVO_H_

void init_servo(void);
void move_up(void);
void move_down(void);

#endif /* SERVO_H_ */