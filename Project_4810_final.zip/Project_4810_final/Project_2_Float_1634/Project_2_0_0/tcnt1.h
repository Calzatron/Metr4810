/*
 * tcnt1.h
 *
 * Created: 12/05/2017 6:14:35 PM
 *  Author: Ryan
 */ 


#ifndef TCNT1_H_
#define TCNT1_H_

void pwm_initialiser(void);

#endif /* TCNT1_H_ */